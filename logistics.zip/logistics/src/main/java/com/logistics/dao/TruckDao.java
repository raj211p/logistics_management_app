package com.logistics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.logistics.util.DBConnection;
import com.logistics.bean.Truck;

public class TruckDao {
	  public boolean addTruck(Truck truck) {
		    Connection con = DBConnection.createConnection();
		    String sql = "insert into Truck values (?,?,?,?) ";
		    int i=0;
		    try {
		    	PreparedStatement preparedStatement = con.prepareStatement(sql);
		    	preparedStatement.setInt(1, truck.getId());
		    	preparedStatement.setString(2, truck.getManufacturer());
		    	preparedStatement.setString(3, truck.getModel());
		    	preparedStatement.setInt(4, truck.getmaxcargoload());
		    	i=preparedStatement.executeUpdate();
		    } catch (SQLException e) {
		    	e.printStackTrace();
		    	
		    } finally {}
		    if(i==0) {
		    	return false;
		    }
		    else {
		    	return true;
		    }
	  }
	  
	  public boolean editTruck(Truck truck) {
		  Connection con= DBConnection.createConnection();
		  String sql="update Truck set Max_cargo_load=? where Truck_ID=?";
		  int i=0;
		  try {
			  PreparedStatement preparedStatement=con.prepareStatement(sql);
			  preparedStatement.setInt(1,truck.getmaxcargoload());
			  preparedStatement.setInt(2,truck.getId());
			  System.out.print(preparedStatement+" "+truck.getId());
			  i=preparedStatement.executeUpdate();
		    } catch (SQLException e) {
		    	e.printStackTrace();
		    	
		    }
		    if(i==0) {
		    	return false;
		    }
		    else {
		    	return true;
		    }
	  }
	  
	  public void deleteTruck(int Truck_ID) {
		  Connection con=DBConnection.createConnection();
		  String sql="Delete from Truck where Truck_ID=?";
		  try {
			  PreparedStatement preparedStatement = con.prepareStatement(sql);
			  preparedStatement.setInt(1, Truck_ID);
			  preparedStatement.executeUpdate();
		    } catch (SQLException e) {
		    	e.printStackTrace();
		    	
		    }
	  }
	  
}
