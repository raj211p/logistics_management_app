package com.logistics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.logistics.util.DBConnection;
import com.logistics.bean.Order;

public class OrderDao {
	public boolean addOrder(Order order) {
		Connection con = DBConnection.createConnection();
	    String sql = "insert into Orders values (?,?,?,?,?,?,?) ";
	    int i=0;
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql);
	    	preparedStatement.setInt(1, order.getOrderId());
	    	preparedStatement.setInt(2, order.getCustomerId());
	    	preparedStatement.setString(3, order.getCargo_desc());
	    	preparedStatement.setString(4, order.getOrigin());
	    	preparedStatement.setString(5, order.getDestination());
	    	preparedStatement.setInt(6,order.getGross_wt());
	    	preparedStatement.setString(7,order.getStatus());
	    	i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
	}
	public boolean editOrder(Order order,int orderid) {
		  Connection con= DBConnection.createConnection();
		  String sqlcheck="Select Status from Orders Where Order_ID=?";
		  String status="";
		  try {
		  PreparedStatement preparedStatement1=con.prepareStatement(sqlcheck);
		  preparedStatement1.setInt(1,orderid);
		  ResultSet resultSet = preparedStatement1.executeQuery();
		  while(resultSet.next()) {
			  status=resultSet.getString(1);
			  }
		  }
		  catch (SQLException e) {
			  e.printStackTrace();
		  }
		  
		  if(status.equals("Undergoing processing"))
		  {	        
			  String sql="update Orders set Cargo_desc=?, Origin=?, Destination=?, Gross_wt=? where Order_ID=?";
			  int i=0;
			  try {
				  PreparedStatement preparedStatement=con.prepareStatement(sql);
				  preparedStatement.setString(1,order.getCargo_desc());
				  preparedStatement.setString(2,order.getOrigin());
				  preparedStatement.setString(3,order.getDestination());
				  preparedStatement.setInt(4,order.getGross_wt());
				  preparedStatement.setInt(5, order.getOrderId());
				  i=preparedStatement.executeUpdate();
			    } catch (SQLException e) {
			    	e.printStackTrace();
			    	
			    }
			    if(i==0) {
			    	return false;
			    }
			    else {
			    	return true;
			    }
		  }
		  else {
			  return false;
		  }
	}
	public void deleteOrder(int Order_ID) {
		  Connection con=DBConnection.createConnection();
		  String sql="Delete from Orders where Order_ID=?";
		  try {
			  PreparedStatement preparedStatement = con.prepareStatement(sql);
			  preparedStatement.setInt(1, Order_ID);
			  preparedStatement.executeUpdate();
		    } catch (SQLException e) {
		    	e.printStackTrace();
		    	
		    }
	  }

}
