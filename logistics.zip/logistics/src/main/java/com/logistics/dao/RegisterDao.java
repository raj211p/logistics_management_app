package com.logistics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.logistics.util.DBConnection;
import com.logistics.bean.RegistrationBean;

public class RegisterDao {
	public boolean addCustomer(RegistrationBean regBean) {
	    Connection con = DBConnection.createConnection();
	    String sql = "insert into Users values (?,?,?) ";
	    int i=0,j=0;
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql);
	    	preparedStatement.setString(1, regBean.getUserName());
	    	preparedStatement.setString(2, regBean.getPassword());
	    	preparedStatement.setString(3, "Customer"); //hardcoded
	    	i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    
	    String sql2 = "insert into Customer values (?,?) ";
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql2);
	    	preparedStatement.setInt(1, regBean.getCustomerId());
	    	preparedStatement.setString(2, regBean.getUserName());
	    	j=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    
	    
	    if(i==0 || j==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }

}
