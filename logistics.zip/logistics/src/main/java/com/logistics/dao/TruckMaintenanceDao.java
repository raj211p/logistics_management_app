package com.logistics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.logistics.bean.TruckMaintenance;
import com.logistics.util.DBConnection;

public class TruckMaintenanceDao {
	public boolean addTruckMaintenance(TruckMaintenance truckm) {
	    Connection con = DBConnection.createConnection();
	    String sql = "insert into Maintenance_truck values (?,?,?) ";
	    int i=0;
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql);
	    	preparedStatement.setInt(1, truckm.getEngineerId());
	    	preparedStatement.setInt(2, truckm.getTruckId());
	    	preparedStatement.setInt(3, truckm.getHoursSpent());
	    	
	    	i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public boolean editTruckMaintenance(TruckMaintenance truckm) {
	  Connection con= DBConnection.createConnection();
	  String sql="update Maintenance_truck set Hours_spent=? where Truck_ID=? AND Engineer_ID=?";
	  int i=0;
	  try {
		  PreparedStatement preparedStatement=con.prepareStatement(sql);
		  preparedStatement.setInt(1,truckm.getHoursSpent());
		  preparedStatement.setInt(2,truckm.getTruckId());
		  preparedStatement.setInt(3,truckm.getEngineerId());
		  i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public void deleteTruckMaintenance(int Truck_ID,int Engineer_ID) {
	  Connection con=DBConnection.createConnection();
	  String sql="Delete from Maintenance_truck where Truck_ID=? AND Engineer_ID=?";
	  try {
		  PreparedStatement preparedStatement = con.prepareStatement(sql);
		  preparedStatement.setInt(1, Truck_ID);
		  preparedStatement.setInt(2, Engineer_ID);
		  preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
  }
}
