package com.logistics.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.logistics.bean.LoginBean;
import com.logistics.util.DBConnection;

public class LoginDao {

public String authenticateUser(LoginBean loginBean)
{
	String userName = loginBean.getUserName();
	String password = loginBean.getPassword();

	Connection con = null;
	Statement statement = null;
	ResultSet resultSet = null;

	String userNameDB = "";
	String passwordDB = "";
	String roleDB = "";

	try
	{
		con = DBConnection.createConnection();
		statement = con.createStatement();
		resultSet = statement.executeQuery("select Username,Password,Role from Users");

		while(resultSet.next())
		{
			userNameDB = resultSet.getString("Username");
			passwordDB = resultSet.getString("Password");
			roleDB = resultSet.getString("Role");

			if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Admin"))
			return "Admin_Role";
			else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Customer"))
			return "Customer_Role";
			else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Vehicle_maintenance"))
			return "Vehicle_maintenance_role";
			else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Aircraft_maintenance"))
			return "Aircraft_maintenance_role";
		}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return "Invalid user credentials";
}

}
