package com.logistics.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.logistics.util.DBConnection;
import com.logistics.bean.MaintenanceEngineer;

public class MaintenanceEngineerDao {
	public boolean addMaintenanceEngineer(MaintenanceEngineer maintenanceengineer) {
	    Connection con = DBConnection.createConnection();
	    String sql = "insert into Maintenance_engineer values (?,?,?) ";
	    int i=0;
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql);
	    	preparedStatement.setInt(1, maintenanceengineer.getEngineerId());
	    	preparedStatement.setString(2, maintenanceengineer.getName());
	    	preparedStatement.setInt(3, maintenanceengineer.getSalary());
	    	i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public boolean editMaintenanceEngineer(MaintenanceEngineer maintenanceengineer) {
	  Connection con= DBConnection.createConnection();
	  String sql="update Maintenance_engineer set Salary=? where Engineer_ID=?";
	  int i=0;
	  try {
		  PreparedStatement preparedStatement=con.prepareStatement(sql);
		  preparedStatement.setInt(1, maintenanceengineer.getSalary());
		  preparedStatement.setInt(2, maintenanceengineer.getEngineerId());
	      i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public void deleteMaintenanceEngineer(int Engineer_ID) {
	  Connection con=DBConnection.createConnection();
	  String sql="Delete from Maintenance_engineer where Engineer_ID=?";
	  try {
		  PreparedStatement preparedStatement = con.prepareStatement(sql);
		  preparedStatement.setInt(1, Engineer_ID);
		  preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
  }
}
