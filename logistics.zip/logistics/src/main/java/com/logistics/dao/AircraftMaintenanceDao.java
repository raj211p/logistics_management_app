package com.logistics.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.logistics.bean.AircraftMaintenance;
import com.logistics.util.DBConnection;

public class AircraftMaintenanceDao {
	public boolean addAircraftMaintenance(AircraftMaintenance aircraftm) {
	    Connection con = DBConnection.createConnection();
	    String sql = "insert into Technician_aircraft values (?,?,?) ";
	    int i=0;
	    try {
	    	PreparedStatement preparedStatement = con.prepareStatement(sql);
	    	preparedStatement.setInt(1, aircraftm.getTechnicianId());
	    	preparedStatement.setInt(2, aircraftm.getAircraftId());
	    	preparedStatement.setInt(3, aircraftm.getHoursSpent());
	    	
	    	i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    } finally {}
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public boolean editAircraftMaintenance(AircraftMaintenance aircraftm) {
	  Connection con= DBConnection.createConnection();
	  String sql="update Technician_aircraft set Hours_spent=? where Aircraft_ID=? AND Technician_ID=?";
	  int i=0;
	  try {
		  PreparedStatement preparedStatement=con.prepareStatement(sql);
		  preparedStatement.setInt(1,aircraftm.getHoursSpent());
		  preparedStatement.setInt(2,aircraftm.getAircraftId());
		  preparedStatement.setInt(3,aircraftm.getTechnicianId());
		  i=preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
	    if(i==0) {
	    	return false;
	    }
	    else {
	    	return true;
	    }
  }
  
  public void deleteAircraftMaintenance(int Aircraft_ID,int Technician_ID) {
	  Connection con=DBConnection.createConnection();
	  String sql="Delete from Technician_aircraft where Aircraft_ID=? AND Technician_ID=?";
	  try {
		  PreparedStatement preparedStatement = con.prepareStatement(sql);
		  preparedStatement.setInt(1, Aircraft_ID);
		  preparedStatement.setInt(2, Technician_ID);
		  preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    	
	    }
  }

}
