package com.logistics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.logistics.util.DBConnection;
import com.logistics.bean.Order;

public class OrderDao2 {
	public boolean editOrder(Order order,String status) {
		  Connection con= DBConnection.createConnection();
		  String sql="update Orders set Status=? where Order_ID=?";
		  int i=0;
		   try {
				  PreparedStatement preparedStatement=con.prepareStatement(sql);
				  preparedStatement.setString(1,status);
				  preparedStatement.setInt(2,order.getOrderId());
				  i=preparedStatement.executeUpdate();
			    } catch (SQLException e) {
			    	e.printStackTrace();
			    	
			    }
			    if(i==0) {
			    	return false;
			    }
			    else {
			    	return true;
			    }
		  }
		  
	
	public void deleteOrder(int Order_ID) {
		  Connection con=DBConnection.createConnection();
		  String sql="Delete from Orders where Order_ID=?";
		  try {
			  PreparedStatement preparedStatement = con.prepareStatement(sql);
			  preparedStatement.setInt(1, Order_ID);
			  preparedStatement.executeUpdate();
		    } catch (SQLException e) {
		    	e.printStackTrace();
		    	
		    }
	  }

}
