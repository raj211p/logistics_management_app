package com.logistics.controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.dao.AircraftMaintenanceDao;
import com.logistics.dao.TruckMaintenanceDao;
import com.logistics.bean.AircraftMaintenance;
import com.logistics.bean.TruckMaintenance;

public class AircraftMaintenanceServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public AircraftMaintenanceServlet() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
	      if (request.getParameter("Action").equals("Add Aircraft Maintenance Record")) {
	      System.out.println("in");
	      PrintWriter printWriter = response.getWriter();
	      AircraftMaintenance aircraftm = new AircraftMaintenance();
	      AircraftMaintenanceDao aircraftmdao = new AircraftMaintenanceDao();
	      String temp=request.getParameter("Aircraft_ID");
	      int ar_id=Integer.parseInt(temp);
	     // String temp2=request.getParameter("Max_cargo_load");
	     // int mcl=Integer.parseInt(temp2);
	      aircraftm.setAircraftId(ar_id);
	      String temp2=request.getParameter("Technician_ID");
	      int tech_id=Integer.parseInt(temp2);
	      aircraftm.setTechnicianId(tech_id);
	      String temp3=request.getParameter("Hours_spent");
	      int Hours_spent=Integer.parseInt(temp3);
	      aircraftm.setHoursSpent(Hours_spent);
	      //truck.setManufacturer(request.getParameter("Manufacturer"));
	     // truck.setModel(request.getParameter("Model"));
	      //truck.setmaxcargoload(mcl);
	      

	      boolean result = aircraftmdao.addAircraftMaintenance(aircraftm);
	      System.out.print(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_air_add.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>The new record was added successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Edit Aircraft Maintenance Record")) {
	      PrintWriter printWriter = response.getWriter();
	      AircraftMaintenance aircraftm = new AircraftMaintenance();
	      AircraftMaintenanceDao aircraftmdao = new AircraftMaintenanceDao();
	      String temp=request.getParameter("Aircraft_ID");
	      String temp2=request.getParameter("Technician_ID");
	      aircraftm.setAircraftId(Integer.parseInt(temp));
	      aircraftm.setTechnicianId(Integer.parseInt(temp2));
	      aircraftm.setHoursSpent(Integer.parseInt(request.getParameter("Hours_spent")));
	      boolean result = aircraftmdao.editAircraftMaintenance(aircraftm);
	      System.out.println(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_air_edit.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry updated Successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Delete Aircraft Maintenance Record")) {
	      PrintWriter printWriter = response.getWriter();
	      AircraftMaintenance aircraftm = new AircraftMaintenance();
	      AircraftMaintenanceDao aircraftmdao = new AircraftMaintenanceDao();
	      aircraftmdao.deleteAircraftMaintenance(Integer.parseInt(request.getParameter("Aircraft_ID")),Integer.parseInt(request.getParameter("Technician_ID")));
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_air_delete.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry deleted successfully.</h2>");
	    }
	  }

}
