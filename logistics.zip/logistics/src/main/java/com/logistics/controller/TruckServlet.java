package com.logistics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.dao.TruckDao;
import com.logistics.bean.Truck;

public class TruckServlet extends HttpServlet{
	  private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public TruckServlet() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
	      if (request.getParameter("Action").equals("Add Truck")) {
	      System.out.println("in");
	      PrintWriter printWriter = response.getWriter();
	      Truck truck = new Truck();
	      TruckDao truckdao = new TruckDao();
	      String temp=request.getParameter("Truck_ID");
	      int tr_id=Integer.parseInt(temp);
	      String temp2=request.getParameter("Max_cargo_load");
	      int mcl=Integer.parseInt(temp2);
	      truck.setId(tr_id);
	      truck.setManufacturer(request.getParameter("Manufacturer"));
	      truck.setModel(request.getParameter("Model"));
	      truck.setmaxcargoload(mcl);

	      boolean result = truckdao.addTruck(truck);
	      System.out.print(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("truckadd.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>The new truck was added successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Edit")) {
	      PrintWriter printWriter = response.getWriter();
	      Truck truck = new Truck();
	      TruckDao truckdao = new TruckDao();
	      truck.setId(Integer.parseInt(request.getParameter("Truck_ID")));
	      String temp2=request.getParameter("Max_cargo_load");
	      int mcl=Integer.parseInt(temp2); truck.setmaxcargoload(mcl);
	      boolean result = truckdao.editTruck(truck);
	      System.out.println(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("truckedit.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry updated successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Delete")) {
	      PrintWriter printWriter = response.getWriter();
	      Truck truck = new Truck();
	      TruckDao truckdao = new TruckDao();
	      truckdao.deleteTruck(Integer.parseInt(request.getParameter("Truck_ID")));
	      RequestDispatcher dispatcher = request.getRequestDispatcher("truckdelete.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry deleted successfully.</h2>");
	    }
	  }
}
