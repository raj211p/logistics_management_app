package com.logistics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.dao.OrderDao2;
import com.logistics.bean.Order;

public class OrderServlet2 extends HttpServlet{
	private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public OrderServlet2() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
		      
		    if (request.getParameter("Action").equals("Edit")) {
			      PrintWriter printWriter = response.getWriter();
			      Order order = new Order();
			      OrderDao2 orderdao2 = new OrderDao2();
			      order.setOrderId(Integer.parseInt(request.getParameter("Order_ID")));
			      order.setCargo_desc(request.getParameter("Cargo_desc"));
			      order.setOrigin(request.getParameter("Origin"));
			      order.setDestination(request.getParameter("Destination"));
			      order.setGross_wt(Integer.parseInt(request.getParameter("Gross_wt")));
			      order.setStatus(request.getParameter("Status"));
			      System.out.print(Integer.parseInt(request.getParameter("Order_ID")));
			      String status=request.getParameter("Status");
			      boolean result = orderdao2.editOrder(order,status);
			      System.out.println(result);
			      RequestDispatcher dispatcher = request.getRequestDispatcher("orderedit2.jsp");
			      dispatcher.include(request, response);
			      if(result==true) {
			    	  printWriter.print("<br><h2>Order details updated successfully.</h2>");
			      }
			      else {
			    	  System.out.print("Error!");
			      }
			      
				 
		    }
		    if(request.getParameter("Action").equals("Delete")) {
		    	  PrintWriter printWriter = response.getWriter();
		    	  Order order = new Order();
			      OrderDao2 orderdao2 = new OrderDao2();
			      orderdao2.deleteOrder(Integer.parseInt(request.getParameter("Order_ID")));
			      RequestDispatcher dispatcher = request.getRequestDispatcher("orderdelete2.jsp");
			      dispatcher.include(request, response);
			      printWriter.print("<br><h2>Order cancelled successfully.</h2>");
		    }
//Pass 2 parameters to editOrder()!
}

}
