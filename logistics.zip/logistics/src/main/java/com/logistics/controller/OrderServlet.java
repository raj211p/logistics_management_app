package com.logistics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.dao.OrderDao;
import com.logistics.bean.Order;

public class OrderServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public OrderServlet() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {
		      if (request.getParameter("Action").equals("Add")) {
			      System.out.println("in");
			      PrintWriter printWriter = response.getWriter();
			      Order order = new Order();
			      OrderDao orderdao = new OrderDao();
			      String temp=request.getParameter("Order_ID");
			      int order_id=Integer.parseInt(temp);
			      String temp2=request.getParameter("Customer_ID");
			      int cust_id=Integer.parseInt(temp2);
			      String gwt=request.getParameter("Gross_wt");
			      int grosswt=Integer.parseInt(gwt);
			      order.setOrderId(order_id);
			      order.setCustomerId(cust_id);
			      order.setCargo_desc(request.getParameter("Cargo_desc"));
			      order.setOrigin(request.getParameter("Origin"));
			      order.setDestination(request.getParameter("Destination"));
			      order.setGross_wt(grosswt);
			      order.setStatus("Undergoing processing");
			      
			      boolean result = orderdao.addOrder(order);
			      System.out.print(result);
			      RequestDispatcher dispatcher = request.getRequestDispatcher("orderadd.jsp");
			      dispatcher.include(request, response);
			      printWriter.print("<br><h2>Your shipment order was placed successfully.</h2>");
			}
		    if (request.getParameter("Action").equals("Edit")) {
			      PrintWriter printWriter = response.getWriter();
			      Order order = new Order();
			      OrderDao orderdao = new OrderDao();
			      order.setOrderId(Integer.parseInt(request.getParameter("Order_ID")));
			      order.setCargo_desc(request.getParameter("Cargo_desc"));
			      order.setOrigin(request.getParameter("Origin"));
			      order.setDestination(request.getParameter("Destination"));
			      order.setGross_wt(Integer.parseInt(request.getParameter("Gross_wt")));
			      System.out.print(Integer.parseInt(request.getParameter("Order_ID")));
			      int orderid=Integer.parseInt(request.getParameter("Order_ID"));
			      boolean result = orderdao.editOrder(order,orderid);
			      System.out.println(result);
			      RequestDispatcher dispatcher = request.getRequestDispatcher("orderedit.jsp");
			      dispatcher.include(request, response);
			      if(result==true) {
			    	  printWriter.print("<br><h2>Order details updated successfully.</h2>");
			      }
			      else {
			    	  printWriter.print("<br><h2>Sorry, this order cannot be updated.</h2>");
			      }
			      
				 
		    }
		    if(request.getParameter("Action").equals("Delete")) {
		    	  PrintWriter printWriter = response.getWriter();
		    	  Order order = new Order();
			      OrderDao orderdao = new OrderDao();
			      orderdao.deleteOrder(Integer.parseInt(request.getParameter("Order_ID")));
			      RequestDispatcher dispatcher = request.getRequestDispatcher("orderdelete.jsp");
			      dispatcher.include(request, response);
			      printWriter.print("<br><h2>Order cancelled successfully.</h2>");
		    }
//Pass 2 parameters to editOrder()!
}
}
