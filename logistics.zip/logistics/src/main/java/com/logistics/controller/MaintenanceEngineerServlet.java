package com.logistics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.dao.MaintenanceEngineerDao;
import com.logistics.bean.MaintenanceEngineer;

public class MaintenanceEngineerServlet extends HttpServlet{
	  private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public MaintenanceEngineerServlet() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
	      if (request.getParameter("Action").equals("Add")) {
	      System.out.println("in");
	      PrintWriter printWriter = response.getWriter();
	      MaintenanceEngineer maintenanceengineer = new MaintenanceEngineer();
	      MaintenanceEngineerDao maintenanceengineerdao = new MaintenanceEngineerDao();
	      String temp=request.getParameter("Engineer_ID");
	      int emp_id=Integer.parseInt(temp);
	      String temp2=request.getParameter("Name");
	      String temp3=request.getParameter("Salary");
	      int salary=Integer.parseInt(temp3);
	      maintenanceengineer.setEngineerId(emp_id);
	      maintenanceengineer.setName(temp2);
	      maintenanceengineer.setSalary(salary);
	      
	      boolean result = maintenanceengineerdao.addMaintenanceEngineer(maintenanceengineer);
	      System.out.print(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_engineer_add.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>The new employee was added successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Edit")) {
	      PrintWriter printWriter = response.getWriter();
	      MaintenanceEngineer maintenanceengineer = new MaintenanceEngineer();
	      MaintenanceEngineerDao maintenanceengineerdao = new MaintenanceEngineerDao();
	      String temp=request.getParameter("Engineer_ID");
	      int emp_id=Integer.parseInt(temp);
	      String temp2=request.getParameter("Salary");
	      int salary=Integer.parseInt(temp2); 
	      maintenanceengineer.setEngineerId(emp_id);
	      maintenanceengineer.setSalary(salary);
	      boolean result = maintenanceengineerdao.editMaintenanceEngineer(maintenanceengineer);
	      System.out.println(result);
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_engineer_edit.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry updated successfully.</h2>");
	    }
	    if (request.getParameter("Action").equals("Delete")) {
	      PrintWriter printWriter = response.getWriter();
	      MaintenanceEngineer maintenanceengineer = new MaintenanceEngineer();
	      MaintenanceEngineerDao maintenanceengineerdao = new MaintenanceEngineerDao();
	      maintenanceengineerdao.deleteMaintenanceEngineer(Integer.parseInt(request.getParameter("Engineer_ID")));
	      RequestDispatcher dispatcher = request.getRequestDispatcher("maint_engineer_delete.jsp");
	      dispatcher.include(request, response);
	      printWriter.print("<br><h2>Entry deleted successfully.</h2>");
	    }
	  }
}