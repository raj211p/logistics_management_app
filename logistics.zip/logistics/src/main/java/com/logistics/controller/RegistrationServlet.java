package com.logistics.controller;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logistics.bean.RegistrationBean;
import com.logistics.dao.RegisterDao;

public class RegistrationServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	  /**
	   * @see HttpServlet#HttpServlet()
	   */
	  public RegistrationServlet() {
	    super();
	    // TODO Auto-generated constructor stub
	  }
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)
		      throws ServletException, IOException {
		      System.out.println("in");
		      PrintWriter printWriter = response.getWriter();
		      RegistrationBean regBean = new RegistrationBean();
		      RegisterDao registerdao = new RegisterDao();
		      String temp=request.getParameter("Customer_ID");
		      int cust_id=Integer.parseInt(temp);
		      String temp2=request.getParameter("username");
		      String temp3=request.getParameter("password");
		      regBean.setCustomerId(cust_id);
		      regBean.setUserName(temp2);
		      regBean.setPassword(temp3);
		      
		      boolean result = registerdao.addCustomer(regBean);
		      System.out.print(result);
		      RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.jsp");
		      dispatcher.include(request, response);
		      if(result==true)
		      {
		    	  printWriter.print("<br><h2>Registration completed successfully. You may log into your account to place shipment orders.</h2>");
		      }
		      else
		    	  printWriter.print("<br><h2>Registration failed!</h2>");
		    }
	  
}
