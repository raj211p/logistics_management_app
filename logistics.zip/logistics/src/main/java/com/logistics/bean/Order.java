package com.logistics.bean;

public class Order {
	private int Order_ID;
	private int Customer_ID;
	private String Cargo_desc;
	private String Origin;
	private String Destination;
	private int Gross_wt;
	private String Status;
	
	public int getOrderId()
	{
		return Order_ID;
	}
	public void setOrderId(int Order_ID)
	{
		this.Order_ID=Order_ID;
	}
	public int getCustomerId()
	{
		return Customer_ID;
	}
	public void setCustomerId(int Customer_ID)
	{
		this.Customer_ID=Customer_ID;
	}
	public String getCargo_desc()
	{
		return Cargo_desc;
	}
	public void setCargo_desc(String Cargo_desc)
	{
		this.Cargo_desc=Cargo_desc;
	}
	public String getOrigin()
	{
		return Origin;
	}
	public void setOrigin(String Origin)
	{
		this.Origin=Origin;
	}
	public String getDestination()
	{
		return Destination;
	}
	public void setDestination(String Destination)
	{
		this.Destination=Destination;
	}
	public int getGross_wt()
	{
		return Gross_wt;
	}
	public void setGross_wt(int Gross_wt)
	{
		this.Gross_wt=Gross_wt;
	}
	public String getStatus()
	{
		return Status;
	}
	public void setStatus(String Status)
	{
		this.Status=Status;
	}
	public Order(int Order_ID, int Customer_ID, String Cargo_desc, String Origin, String Destination, int Gross_wt, String Status) 
	{
		this.Order_ID=Order_ID;
		this.Customer_ID=Customer_ID; this.Cargo_desc=Cargo_desc; this.Origin=Origin; this.Destination=Destination; this.Gross_wt=Gross_wt;
		this.Status=Status;
	}
	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	 }
}
