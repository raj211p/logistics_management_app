package com.logistics.bean;

public class TruckMaintenance {
	private int Truck_ID;
	private int Engineer_ID;
	private int Hours_spent;
	
	public int getTruckId()
	{
		return Truck_ID;
	}
	public void setTruckId(int Truck_ID)
	{
		this.Truck_ID=Truck_ID;
	}
	public int getEngineerId()
	{
		return Engineer_ID;
	}
	public void setEngineerId(int Engineer_ID)
	{
		this.Engineer_ID=Engineer_ID;
	}
	public int getHoursSpent()
	{
		return Hours_spent;
	}
	public void setHoursSpent(int Hours_spent)
	{
		this.Hours_spent=Hours_spent;
	}
}
