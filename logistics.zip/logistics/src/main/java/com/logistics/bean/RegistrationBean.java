package com.logistics.bean;

public class RegistrationBean {
	private int Customer_ID;
	private String userName;
	private String password;

	public int getCustomerId() {
		return Customer_ID;
	}
	public void setCustomerId(int Customer_ID) {
		this.Customer_ID = Customer_ID;
	}
	public String getUserName() {
	return userName;
	}
	public void setUserName(String userName) {
	this.userName = userName;
	}
	public String getPassword() {
	return password;
	}
	public void setPassword(String password) {
	this.password = password;
	}
	


}
