package com.logistics.bean;

public class MaintenanceEngineer {
	private int Engineer_ID;
	private String Name;
	private int Salary;
	
	public int getEngineerId()
	{
		return Engineer_ID;
	}
	public void setEngineerId(int Engineer_ID)
	{
		this.Engineer_ID=Engineer_ID;
	}
	public String getName()
	{
		return Name;
	}
	public void setName(String Name)
	{
		this.Name=Name;
	}
	public int getSalary()
	{
		return Salary;
	}
	public void setSalary(int Salary)
	{
		this.Salary=Salary;
	}
}
