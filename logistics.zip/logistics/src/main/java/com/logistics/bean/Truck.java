package com.logistics.bean;

public class Truck {
	private int Truck_ID;
	private String manufacturer;
	private String model ;
	private int Max_cargo_load;
	
	public int getId()
	{
		return Truck_ID;
	}
	public void setId(int Truck_ID)
	{
		this.Truck_ID=Truck_ID;
	}
	public String getManufacturer()
	{
		return manufacturer;
	}
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer=manufacturer;
	}
	public String getModel()
	{
		return model;
	}
	public void setModel(String model)
	{
		this.model=model;
	}
	public int getmaxcargoload()
	{
		return Max_cargo_load;
	}
	public void setmaxcargoload(int Max_cargo_load)
	{
		this.Max_cargo_load=Max_cargo_load;
	}
	
	public Truck(int Truck_ID, String manufacturer, String model, int Max_cargo_load) {
		this.Truck_ID=Truck_ID;
		this.manufacturer=manufacturer;
		this.model=model;
		this.Max_cargo_load=Max_cargo_load;
	}
	
	public Truck() {
		super();
		// TODO Auto-generated constructor stub
	 }
}