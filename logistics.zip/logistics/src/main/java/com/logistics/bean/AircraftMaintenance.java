package com.logistics.bean;

public class AircraftMaintenance {
	private int Aircraft_ID;
	private int Technician_ID;
	private int Hours_spent;
	
	public int getAircraftId()
	{
		return Aircraft_ID;
	}
	public void setAircraftId(int Aircraft_ID)
	{
		this.Aircraft_ID=Aircraft_ID;
	}
	public int getTechnicianId()
	{
		return Technician_ID;
	}
	public void setTechnicianId(int Technician_ID)
	{
		this.Technician_ID=Technician_ID;
	}
	public int getHoursSpent()
	{
		return Hours_spent;
	}
	public void setHoursSpent(int Hours_spent)
	{
		this.Hours_spent=Hours_spent;
	}
}
